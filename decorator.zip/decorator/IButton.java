package game.languagelearning.decorator;

import android.widget.Button;

public interface IButton {

    Button getButton();
    void setBackgroundColor();
}
