package game.languagelearning.decorator;

import android.graphics.Color;
import android.widget.Button;

public class ButtonGreen extends ButtonDecorator {

    public ButtonGreen(Button button) {
        super(button);
    }

    @Override
    public Button getButton() {
        setBackgroundColor();
        return super.btn;
    }

    @Override
    public void setBackgroundColor() {
        super.btn.setBackgroundColor(Color.GREEN);
    }
}