package game.languagelearning.decorator;

import android.graphics.Color;
import android.widget.Button;

public class ButtonBlue extends ButtonDecorator {

    public ButtonBlue(Button button) {
        super(button);
    }

    @Override
    public Button getButton() {
        setBackgroundColor();
        return super.btn;
    }

    @Override
    public void setBackgroundColor() {
        super.btn.setBackgroundColor(Color.BLUE);
    }
}