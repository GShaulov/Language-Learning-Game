package game.languagelearning.decorator;

import android.widget.Button;

public abstract class ButtonDecorator implements IButton {

    Button btn;

    public ButtonDecorator(Button btn) {
        this.btn = btn;
    }


}