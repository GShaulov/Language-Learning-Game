package game.languagelearning.memento;

import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;

public class LevelMemento {
    private String userName;
    private int nativeLng;
    private int level;
    private int point;
    private boolean[] checkedLng;
    private boolean isLoaded;
    private ArrayList<String> saves;

    //constructor
    public LevelMemento() {
        this.saves= new ArrayList<>();
//        loadUsers();
    }
    public LevelMemento(String userName, int nativeLng, int level, int point, boolean[] checkedLng) {
        this.saves= new ArrayList<>();
        this.userName = userName;
        this.nativeLng = nativeLng;
        this.level = level;
        this.point=point;
        this.checkedLng= checkedLng;
    }


    //getters and setters
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserName(int k) {
        String line = saves.get(k);
        return line.substring(line.indexOf("<userName>")+10,line.indexOf("</userName>"));
    }
    public int getNativeLng() {
        return nativeLng;
    }
    public void setNativeLng(int nativeLng) {
        this.nativeLng = nativeLng;
    }
    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }
    public String getLevel(int k) {
        String line = saves.get(k);
        return line.substring(line.indexOf("<level>")+7,line.indexOf("</level>"));
    }
    public int getPoint(){return point;}
    public void setPoint(int point) {
        this.point = point;
    }
    public boolean[] getCheckedLng() {
        return checkedLng;
    }
    public void setCheckedLng(boolean[] checkedLng) {
        this.checkedLng = checkedLng;
    }
    public boolean isLoaded() {
        return isLoaded;
    }
    public void setLoaded(boolean loaded) {
        isLoaded = loaded;
    }

    //save
    public void save() {
        String usr = "<savedUser>";
        usr += "<userName>"+this.userName+"</userName>";
        usr += "<nativeLng>"+this.nativeLng+"</nativeLng>";
        usr += "<level>"+this.level+"</level>";
        usr += "<point>"+this.point+"</point>";
        usr += "<checkedLng>";
        for(int i=0; i<this.checkedLng.length; i++)
            usr += "<lng>" + this.checkedLng[i] + "</lng>";
        usr += "</checkedLng>";
        usr += "</savedUser>";
        loadSavedGames();
        this.saves.add(0, usr);
        saveSavedGames();
    }
    public void saveLevel(String userName, int nativeLng, int level, int point, boolean[] checkedLng) {
        String usr = "<savedUser>";
        usr += "<userName>"+userName+"</userName>";
        usr += "<nativeLng>"+nativeLng+"</nativeLng>";
        usr += "<level>"+level+"</level>";
        usr += "<point>"+point+"</point>";
        usr += "<checkedLng>";
        for(int i=0; i<checkedLng.length; i++)
            usr += "<lng>" + checkedLng[i] + "</lng>";
        usr += "</checkedLng>";
        usr += "</savedUser>";
        loadSavedGames();
        this.saves.add(0, usr);
        saveSavedGames();
    }
    public void saveSavedGames(){
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/LanguageLearning";
        File dir = new File(path);
        dir.mkdirs();
        File myFile = new File(path + "/save.txt");
        try {
            if (myFile.exists()){
                myFile.delete();
            }
            myFile.createNewFile();
            FileWriter fw = new FileWriter(myFile, true);
            for(int i=0; i<this.saves.size(); i++)
                fw.write(this.saves.get(i)+"\n");
            fw.close();
        }
        catch (FileNotFoundException e2) {}
        catch (IOException e1) {}
    }

    //load
    public void load(String line) {
        this.userName = line.substring(line.indexOf("<userName>")+10,line.indexOf("</userName>"));
        this.nativeLng = Integer.parseInt(line.substring(line.indexOf("<nativeLng>")+11,line.indexOf("</nativeLng>")));
        this.level = Integer.parseInt(line.substring(line.indexOf("<level>")+7,line.indexOf("</level>")));
        this.point = Integer.parseInt(line.substring(line.indexOf("<point>")+7,line.indexOf("</point>")));
        String tempCheckedLng = line.substring(line.indexOf("<checkedLng>")+12,line.indexOf("</checkedLng>"));
        this.checkedLng = new boolean[5];
        try {
            for (int i = 0; i < 5; i++) {
                int begin = tempCheckedLng.indexOf("<lng>") + 5;
                int end = tempCheckedLng.indexOf("</lng>");
                String lng = tempCheckedLng.substring(begin, end);
                this.checkedLng[i] = Boolean.parseBoolean(lng);
                tempCheckedLng = tempCheckedLng.substring(end + 6);
            }
        }catch(Exception e){}
    }
    public void load(int k){
        String line = saves.get(k);
        this.userName = line.substring(line.indexOf("<userName>")+10,line.indexOf("</userName>"));
        this.nativeLng = Integer.parseInt(line.substring(line.indexOf("<nativeLng>")+11,line.indexOf("</nativeLng>")));
        this.level = Integer.parseInt(line.substring(line.indexOf("<level>")+7,line.indexOf("</level>")));
        this.point = Integer.parseInt(line.substring(line.indexOf("<point>")+7,line.indexOf("</point>")));
        String tempCheckedLng = line.substring(line.indexOf("<checkedLng>")+12,line.indexOf("</checkedLng>"));
        this.checkedLng = new boolean[5];
        try {
            for (int i = 0; i < 5; i++) {
                int begin = tempCheckedLng.indexOf("<lng>") + 5;
                int end = tempCheckedLng.indexOf("</lng>");
                String lng = tempCheckedLng.substring(begin, end);
                this.checkedLng[i] = Boolean.parseBoolean(lng);
                tempCheckedLng = tempCheckedLng.substring(end + 6);
            }
        }catch(Exception e){}
    }
    public LevelMemento loadLevel(String line) {
        String memUserName = line.substring(line.indexOf("<userName>")+10,line.indexOf("</userName>"));
        int memNativeLng = Integer.parseInt(line.substring(line.indexOf("<nativeLng>")+11,line.indexOf("</nativeLng>")));
        int memLevel = Integer.parseInt(line.substring(line.indexOf("<level>")+7,line.indexOf("</level>")));
        int memPoint = Integer.parseInt(line.substring(line.indexOf("<point>")+7,line.indexOf("</point>")));
        String tempCheckedLng = line.substring(line.indexOf("<checkedLng>")+12,line.indexOf("</checkedLng>"));
        boolean[] memCheckedLng = new boolean[5];
        try {
            for (int i = 0; i < 5; i++) {
                int begin = tempCheckedLng.indexOf("<lng>") + 5;
                int end = tempCheckedLng.indexOf("</lng>");
                String lng = tempCheckedLng.substring(begin, end);
                memCheckedLng[i] = Boolean.parseBoolean(lng);
                tempCheckedLng = tempCheckedLng.substring(end + 6);
            }
        }catch(Exception e){}
        return new LevelMemento(memUserName, memNativeLng, memLevel, memPoint, memCheckedLng);
    }
    public void loadSavedGames(){
        this.saves = new ArrayList<String>();
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/LanguageLearning";
        File myFile = new File(path + "/save.txt");
        String savedUser="";
        int count=0;
        try {
            if (myFile.exists()) {
                FileInputStream fis = new FileInputStream(myFile);
                Reader in = new InputStreamReader(fis, "UTF8");
                BufferedReader br = new BufferedReader(in);
                while (((savedUser = br.readLine()) != null) && count++ < 10)
                    this.saves.add(savedUser);
            }else{
                isLoaded=false;
            }
        }
        catch (FileNotFoundException e2) {}
        catch (IOException e1){}
        if(this.saves.size()>0) {
            saveSavedGames();
            isLoaded = true;
        }
    }

    public int getSize() {
        return this.saves.size();
    }

}
