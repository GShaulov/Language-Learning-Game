package game.languagelearning.strategy;

import android.app.AlertDialog;

public class SimpleStrategy implements BonusPointStrategy{


    @Override
    public int getBonusPoint(boolean[] checkedLng) {
        int count=0;
        if(checkedLng!=null) {
            for (int i = 0; i < checkedLng.length; i++)
                if (checkedLng[i])
                    ++count;
            return 4*count;
        }else
            return 0;
    }
}
