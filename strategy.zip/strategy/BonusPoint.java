package game.languagelearning.strategy;
public class BonusPoint {
    private BonusPointStrategy strategy;

    public BonusPoint(BonusPointStrategy strategy) {
        setStrategy(strategy);
    }

    public void setStrategy(BonusPointStrategy strategy) {
        this.strategy = strategy;
    }

    public int getBonusPoint(boolean[] checkedLng){
        return strategy.getBonusPoint(checkedLng);
    }

}