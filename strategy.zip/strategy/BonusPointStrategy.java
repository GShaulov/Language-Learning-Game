package game.languagelearning.strategy;

public interface BonusPointStrategy {
    int getBonusPoint(boolean[] checkedLng);
}
