package game.languagelearning.strategy;

public class RestartStrategy implements BonusPointStrategy{


    @Override
    public int getBonusPoint(boolean[] checkedLng) {
        int count=0;
        if(checkedLng!=null) {
            for (int i = 0; i < checkedLng.length; i++)
                if (checkedLng[i])
                    ++count;
            return 2*count;
        }else
            return 0;
    }
}
