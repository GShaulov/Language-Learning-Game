package game.languagelearning.singleton;

import java.util.ArrayList;

public final class SingletonPoint {
	private static	SingletonPoint 	_instance;
    private ArrayList<String[]> users = new ArrayList<>();
    private boolean isRunning=false;
    private String userName="";
    private boolean isNameEntered;

    private int point;
	//constructor
    private SingletonPoint() { }
    //get instance
	public synchronized static SingletonPoint getInstance() {
		if (_instance	== null	) {
		  _instance	= 	new 	SingletonPoint();
		}
		return _instance;
	}
    //plus point method
	public void	plusPoint (int p){	point+=p;		}
    //minus point method
	public void minusPoint(int p){	point-=p;		}
    //get point method
	public int 	getPoint()		 {	return	point;	}
    //set point method
	public int setPoint (int p) {
        point=p;
        return p;
    }
    //check is any level runs
	public boolean isRunning(){return isRunning;}
    //set if any level run
    public void setRunning(boolean b){ isRunning=b;}
    //set user name
    public synchronized void addUser(String[] usr){
        if(users.size()>=15)
            users.remove(14);
        users.add(0,usr);
    }
    //get user name
    public ArrayList<String[]>  getUsers(){ return users;}

    public String setUserName(String userName) {
        this.userName = userName;
        return userName;
    }

    public String getUserName() {
        return userName;
    }
    public boolean isNameEntered(){return isNameEntered;}
    public void setNameEntered(boolean b){ isNameEntered=b;}

}
