package game.languagelearning.factory;

import android.content.Context;

public class WordFactory {
    public AbstractWordShape getWord(int wordType, String word, Context context){
        AbstractWordShape wordShape = null;
        if (wordType == 0) {
            wordShape = new OvalWordShape(word, context);
        } else if (wordType == 1){
            wordShape = new RectWordShape(word, context);
        }
        return wordShape;
    }
}
