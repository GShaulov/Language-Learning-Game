package game.languagelearning.factory;

import android.graphics.Canvas;


public abstract class AbstractWordShape {
    protected String name;
    protected int screenWidth;
    protected int screenHeight;
    protected int shapeWidth;
    protected int shapeHeight;
    protected int locationX;
    protected int locationY;
    protected int speedX;
    protected int speedY;

    public abstract void update();
    public abstract void draw(Canvas canvas);
    public abstract void setDemoColor();
    public abstract boolean isCollision(float evtX,float  evtY);

}
