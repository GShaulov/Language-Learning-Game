package game.languagelearning.factory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.languagelearning.Library;
import game.languagelearning.R;


public class LevelWord {
    private Random rnd;
    private Context context;
    private int x;
    private int y;
    private String[] w;
    private ArrayList<Word> words = new ArrayList<Word>();
    private Bitmap[][] img = new Bitmap[5][5];
    private int[][] imgIcon = {
            {R.drawable.flagshape0,     R.drawable.flagshape1,      R.drawable.flagshape2,      R.drawable.flagshape3,      R.drawable.flagshape4       },
            {R.drawable.rectshape0,     R.drawable.rectshape1,      R.drawable.rectshape2,      R.drawable.rectshape3,      R.drawable.rectshape4       },
            {R.drawable.rectovalshape0, R.drawable.rectovalshape1,  R.drawable.rectovalshape2,  R.drawable.rectovalshape3,  R.drawable.rectovalshape4   },
            {R.drawable.ovalshape0,     R.drawable.ovalshape1,      R.drawable.ovalshape2,      R.drawable.ovalshape3,      R.drawable.ovalshape4       },
            {R.drawable.ovalrectshape0, R.drawable.ovalrectshape1,  R.drawable.ovalrectshape2,  R.drawable.ovalrectshape3,  R.drawable.ovalrectshape4   }
    };

    public LevelWord(Context context ){
        this.context=context;
        this.rnd =new Random();
        this.w = new String[Library.getInstance().getNumOfWords()];
        for(int i=0; i<5; i++)
            for(int j=0; j<5; j++)
                this.img[i][j] = BitmapFactory.decodeResource(context.getResources(), imgIcon[i][j]);
        init(context.getResources().getDisplayMetrics().widthPixels, context.getResources().getDisplayMetrics().heightPixels);
    }

    public void init(int x, int y){
        this.x=x;
        this.y=y;
        for(Word word: words) {
            word.init(x, y);
        }
    }

    public void update() {
        for(Word word: words) {
            word.update();
        }
    }

    public void addWord(Word word){
        words.add(word);
    }

    public void removeWord(Word word){
        words.remove(word);
    }

    public void draw(Canvas canvas) {
        for(Word word: words) {
            word.draw(canvas);
        }
    }

    public int getSize(){
        return words.size();
    }

    public Word getWord(int i){
        return words.get(i);
    }

    public String getWordName(int i){
        return words.get(i).getText();
    }

    public   boolean isCollision(float evtX,float  evtY) {
        return false;
    }

    public void setLevelWords() {
        w = Library.getInstance().getWordsToRemove();
        int row =0;
        int col =1;
        for(int i=0; i<w.length; i++) {
            addWord(new Word(w[i], img[row++][col++], context));
            if(row>=5)   row=0;
            if(col>=5)   col=1;
        }
    }

    public void setDemo() {
        for(int i=0; i<words.size(); i++) {
            for(int k=0; k<w.length; k++)
                if(words.get(i).getText().equals(w[k])){
                    words.get(i).setShape(img[(k%5)][0]);
                    words.get(i).setTextColor(Color.GRAY);
                }
        }
    }

    public ArrayList<Word> getWords() {
        return words;
    }

    public void setWords(ArrayList<Word> words) {
        this.words = words;
    }
}
