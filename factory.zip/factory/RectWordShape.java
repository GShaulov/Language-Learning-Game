package game.languagelearning.factory;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;


public class RectWordShape extends AbstractWordShape {
    private Random rnd;
    private int[][] rndColor = new int[2][3];
    private Context context=null;
    private long locShapeX1;
    private long locShapeX2;
    private long locShapeY1;
    private long locShapeY2;
    public RectWordShape(String wordName, Context context) {
        //word setting
        this.context=context;
        this.rnd = new Random();
        for(int i=0; i<3; i++) {
            int clr = rnd.nextInt(255);
            this.rndColor[0][i] = clr;
            this.rndColor[1][i] = 255 - clr;
        }
        //abstract word settings
        this.name=wordName;
        init();
        this.shapeWidth=220;
        this.shapeHeight=100;
        this.locationX = rnd.nextInt(screenWidth-shapeWidth-220);
        this.locationY = rnd.nextInt(screenHeight-shapeHeight-150)+70;
        this.speedX = rnd.nextInt(3)+3;
        this.speedY = rnd.nextInt(3)+3;
    }

    public void init() {
        this.screenWidth=this.context.getResources().getDisplayMetrics().widthPixels;
        this.screenHeight=this.context.getResources().getDisplayMetrics().heightPixels;
    }

    @Override
    public void update() {
        if (locationX >= screenWidth  - shapeWidth  - speedX || locationX + speedX <= 0)  speedX = -speedX;
        locationX  = locationX + speedX;
        if (locationY >= screenHeight - shapeHeight - speedY-50 || locationY + speedY-70 <= 0)  speedY = -speedY;
        locationY  = locationY + speedY;

    }

    @Override
    public   boolean isCollision(float evtX,float  evtY) {
        return (evtX > locationX) && (evtX < (locationX + shapeWidth)) && (evtY > locationY) && (evtY < (locationY + shapeHeight));
    }


    @Override
    public void draw(Canvas canvas) {
        init();
        if(locationX+200>screenWidth)
            locationX=0;
        if(locationY+100>screenHeight)
            locationY=70;
        Paint paint = new Paint();
        locShapeX1=locationX;
        locShapeX2=locationX + 220;
        locShapeY1=locationY;
        locShapeY2=locationY + 100;
        long locNameX1=locationX+((locShapeX2-locShapeX1)/2)- (name.length()*10);
        long locNameY1=locationY+((locShapeY2-locShapeY1)/2)+10;

        //draw shape
        paint.setColor(Color.rgb(rndColor[1][0],rndColor[1][1],rndColor[1][2]));
        canvas.drawRect(locShapeX1,locShapeY1,locShapeX2, locShapeY2 ,paint);

        //draw word
        paint.setTextSize(35);
        paint.setFakeBoldText(true);
        paint.setColor(Color.rgb(rndColor[0][0],rndColor[0][1],rndColor[0][2]));
        canvas.drawText(name, locNameX1, locNameY1, paint);
    }

    @Override
    public void setDemoColor(){
        int[][] clr = {{156,156,156},{99,99,99}};
        this.rndColor=clr;
    }
}
