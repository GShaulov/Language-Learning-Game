package game.languagelearning.factory;

import android.content.Context;
import android.graphics.Canvas;

import java.util.ArrayList;
import java.util.List;


public class WordCreator extends AbstractWordShape {

    private List<AbstractWordShape> words =new ArrayList<AbstractWordShape>();

    public WordCreator(Context context ){
        this.screenWidth=context.getResources().getDisplayMetrics().widthPixels;
        this.screenHeight=context.getResources().getDisplayMetrics().heightPixels;
    }

    @Override
    public void update() {
        for(AbstractWordShape word1: words) {
            word1.update();
        }
    }

    public void addWord(AbstractWordShape word){
        words.add(word);
    }

    public void removeWord(AbstractWordShape word){
        words.remove(word);
    }

    @Override
    public void draw(Canvas canvas) {
        for(AbstractWordShape word: words) {
            word.draw(canvas);
        }

    }

    @Override
    public void setDemoColor() {
        for(AbstractWordShape word: words) {
            word.setDemoColor();
        }
    }

    public int getSize(){
                return words.size();
    }

    public AbstractWordShape getWord(int i){
        return words.get(i);
    }

    public String getWordName(int i){
        return words.get(i).name;
    }

    @Override
    public   boolean isCollision(float evtX,float  evtY) {
        return false;
    }
}
