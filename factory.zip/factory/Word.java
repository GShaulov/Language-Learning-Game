package game.languagelearning.factory;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

import game.languagelearning.R;


public class Word {
    private String text;
    private Bitmap shape;
    private int textColor =  Color.rgb(228, 221, 160);
    private long locX;
    private long locY;
    private int speedX;
    private int speedY;
    private Context context;
    private int screenWidth;
    private int screenHeight;

    public Word(String text, Bitmap shape, Context context) {
        Random rnd = new Random();
        this.context=context;
        init();
        this.text=text;
        this.shape = shape;
        this.locX=rnd.nextInt(screenWidth-shape.getWidth());
        this.locY=rnd.nextInt(screenHeight-shape.getHeight());
        this.speedX = rnd.nextInt(3)+1;
        this.speedY = rnd.nextInt(3)+1;
    }

    public void init() {
        this.screenWidth=this.context.getResources().getDisplayMetrics().widthPixels;
        this.screenHeight=this.context.getResources().getDisplayMetrics().heightPixels;
    }

    public void init(int x, int y) {
        this.screenWidth=x;
        this.screenHeight=y;
    }

    public void update() {
        if (locX >= screenWidth  - shape.getWidth()  - speedX || locX + speedX <= 0)  speedX = -speedX;
        locX  = locX + speedX;
        if (locY >= screenHeight - shape.getHeight() - speedY || locY + speedY <= 0)  speedY = -speedY;
        locY  = locY + speedY;
    }

    public   boolean isCollision(float evtX,float  evtY) {
        return (evtX > locX) && (evtX < (locX + shape.getWidth())) && (evtY > locY) && (evtY < (locY + shape.getHeight()));
    }


    public void draw(Canvas canvas) {
        update();
        if(locX + shape.getWidth() > screenWidth)
            locX = screenWidth - shape.getHeight();
        if(locY + shape.getHeight() > screenHeight)
            locY = screenHeight - shape.getHeight();
        Paint paint = new Paint();
        long locNameX=locX+( (shape.getWidth()/2) - (text.length()*9));
        long locNameY=locY+(shape.getHeight()*3/5);

        //draw shape
        canvas.drawBitmap(shape, locX, locY, null);

        //draw word
        paint.setTextSize(35);
        paint.setFakeBoldText(true);
        paint.setColor(textColor);
        canvas.drawText(text, locNameX, locNameY, paint);
    }

    public void setTextColor(int color){
        this.textColor=color;
    }

    public void setText(String text) {
        this.text=text;
    }

    public String getText() {
        return this.text;
    }

    public long getLocX() {
        return locX;
    }

    public long getLocY() {
        return locY;
    }

    public int  getShapeWidth(){
        return shape.getWidth();
    }

    public int getShapeHeight(){
        return shape.getHeight();
    }

    public void setShape(Bitmap shape){
        this.shape = shape;
    }
}
